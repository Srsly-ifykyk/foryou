/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class AcousticSynth {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private timer: any = null;
  private delayNode: DelayNode | null = null;
  private feedbackNode: GainNode | null = null;
  private mainGain: GainNode | null = null;

  // Happy Birthday notes (Note name and note values)
  // [pitch, duration, beatOffset]
  private melodyNotes: [number, number][] = [
    [261.63, 0.5], // C4
    [261.63, 0.5], // C4
    [293.66, 1.0], // D4
    [261.63, 1.0], // C4
    [349.23, 1.0], // F4
    [329.63, 2.0], // E4
    
    [261.63, 0.5], // C4
    [261.63, 0.5], // C4
    [293.66, 1.0], // D4
    [261.63, 1.0], // C4
    [392.00, 1.0], // G4
    [349.23, 2.0], // F4

    [261.63, 0.5], // C4
    [261.63, 0.5], // C4
    [523.25, 1.0], // C5
    [440.00, 1.0], // A4
    [349.23, 1.0], // F4
    [329.63, 1.0], // E4
    [293.66, 2.0], // D4

    [466.16, 0.5], // Bb4
    [466.16, 0.5], // Bb4
    [440.00, 1.0], // A4
    [349.23, 1.0], // F4
    [392.00, 1.0], // G4
    [349.23, 2.0], // F4
  ];

  // A romantic, dreamlike backing pad/chord loop
  private ambientChords: number[][] = [
    [174.61, 220.00, 261.63, 329.63], // Fmaj7 (F3, A3, C4, E4)
    [196.00, 246.94, 293.66, 349.23], // G7 (G3, B3, D4, F4)
    [130.81, 196.00, 261.63, 329.63], // Cmaj7 (C3, G3, C4, E4)
    [220.00, 261.63, 329.63, 392.00], // Am7 (A3, C4, E4, G4)
  ];

  private currentBeat = 0;

  getAudioContext(): AudioContext {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === "suspended") {
      this.ctx.resume();
    }
    return this.ctx;
  }

  setupEffects(ctx: AudioContext) {
    if (this.delayNode) return;

    this.mainGain = ctx.createGain();
    this.mainGain.gain.setValueAtTime(0.12, ctx.currentTime);

    // Warm Analog Delay
    this.delayNode = ctx.createDelay(2.0);
    this.delayNode.delayTime.setValueAtTime(0.6, ctx.currentTime);

    this.feedbackNode = ctx.createGain();
    this.feedbackNode.gain.setValueAtTime(0.40, ctx.currentTime);

    // Reverb / Echo coupling
    this.delayNode.connect(this.feedbackNode);
    this.feedbackNode.connect(this.delayNode);

    this.mainGain.connect(ctx.destination);
    this.delayNode.connect(this.mainGain);
  }

  playMusicBoxTone(freq: number, startTime: number, duration: number) {
    const ctx = this.getAudioContext();
    this.setupEffects(ctx);

    if (this.mainGain) {
      // Ensure the volume is audible in case it was muted in stop()
      this.mainGain.gain.setValueAtTime(0.12, ctx.currentTime);
    }

    // Sine wave for soft crystalline tone, slightly coupled with an octave tri-oscillator for warmth
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc1.type = "sine";
    osc1.frequency.setValueAtTime(freq, startTime);

    // Subtle sweet bell vibration
    osc2.type = "triangle";
    osc2.frequency.setValueAtTime(freq * 2, startTime);

    gainNode.gain.setValueAtTime(0, startTime);
    // Plucky attack
    gainNode.gain.linearRampToValueAtTime(0.2, startTime + 0.04);
    // Cozy musical ringout exponential decay
    gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

    osc1.connect(gainNode);
    osc2.connect(gainNode);
    
    // Connect to effects
    gainNode.connect(this.mainGain!);
    gainNode.connect(this.delayNode!);

    osc1.start(startTime);
    osc2.start(startTime);

    osc1.stop(startTime + duration + 0.5);
    osc2.stop(startTime + duration + 0.5);
  }

  // Plays a beautiful chord pad swell
  playArpeggiatedChord(chord: number[], startTime: number) {
    chord.forEach((freq, i) => {
      // Arpeggiate the note entrances by 0.12s for dreamy harp feel
      this.playMusicBoxTone(freq, startTime + i * 0.15, 2.5);
    });
  }

  toggleMusic(onComplete?: () => void) {
    if (this.isPlaying) {
      this.stop();
    } else {
      this.start(onComplete);
    }
  }

  start(onComplete?: () => void) {
    if (this.isPlaying) return;
    this.isPlaying = true;
    
    const ctx = this.getAudioContext();
    let index = 0;
    let nextTime = ctx.currentTime + 0.1;

    const playNext = () => {
      if (!this.isPlaying) return;

      const [freq, duration] = this.melodyNotes[index];
      // Play melody
      this.playMusicBoxTone(freq, nextTime, duration * 1.5);

      // Play soft backing pads every 4 notes
      if (index % 4 === 0) {
        const chordIndex = Math.floor(index / 6) % this.ambientChords.length;
        this.playArpeggiatedChord(this.ambientChords[chordIndex], nextTime);
      }

      nextTime += duration * 0.95; // Speed / BPM controller
      index = (index + 1) % this.melodyNotes.length;

      const delayMs = duration * 950;
      this.timer = setTimeout(playNext, delayMs);
    };

    playNext();
  }

  stop() {
    this.isPlaying = false;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    if (this.mainGain) {
      this.mainGain.gain.setValueAtTime(0, this.getAudioContext().currentTime);
    }
  }

  getPlaying() {
    return this.isPlaying;
  }

  // Little celebration noise
  celebrateSwell() {
    const ctx = this.getAudioContext();
    this.setupEffects(ctx);
    const now = ctx.currentTime;
    
    const chimeFrequencies = [523.25, 587.33, 659.25, 698.46, 783.99, 880.00, 987.77, 1046.50];
    chimeFrequencies.forEach((freq, i) => {
      this.playMusicBoxTone(freq, now + i * 0.08, 1.8);
    });
  }
}

export const MusicBox = new AcousticSynth();
